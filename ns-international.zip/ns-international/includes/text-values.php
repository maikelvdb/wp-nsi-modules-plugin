<?php

class TextValues {

    private static $VALUES = [];

    public static function get($key) {
        
        if (!array_key_exists($key, self::$VALUES)) {
            return get_option("nsi_text_$key", self::DEFAULTS[$key]);
        }
        
        return self::$VALUES[$key];
    }

    public const DEFAULTS = [
        'from' => 'Vertrekstation',
        'to' => 'Aankomststation',
        'date' => 'Vertrek op',
        'search' => 'Zoeken',
        'view_prices' => 'Bekijk prijzen',
        'transfer_amount' => '#x overstappen',
        'no_transfer' => 'Geen overstappen',
        'show_all' => 'Toon alles',
        'search_tickets' => 'Zoek tickets',
        'error-no-data' => 'Kan geen gegevens ophalen, probeer het later opnieuw.',
        'dl_product_name' => 'Trein van {from} naar {to} op {date}',
        'dl_product_description' => 'Goedkoopste treinkaartje van {from} naar {to} op {date} voor {price}',
        'dayschedule-error-no-data'=> 'Geen gegevens gevonden voor deze reis.',
    ];

    public static function getAll() {
        global $wpdb;

        $prefix = 'nsi_text_' . '%';
        $options = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT option_name, option_value 
                FROM $wpdb->options 
                WHERE option_name LIKE %s
                ORDER BY option_id",
                $prefix
            )
        );

        // Convert DB results into key => value pairs
        $results = [];
        foreach ($options as $option) {
            // Remove prefix to make key cleaner (optional)
            $key = str_replace('nsi_text_', '', $option->option_name);
            $results[$key] = $option->option_value;
        }

        // Merge defaults for missing keys
        foreach (self::DEFAULTS as $key => $value) {
            if (!array_key_exists($key, $results)) {
                $results[$key] = $value;
            }
        }

        // Convert to [{ "KEY": "VALUE" }, ... ]
        $formatted = [];
        foreach ($results as $key => $value) {
            $obj = new stdClass();
            $obj->key = $key;
            $obj->value = $value;
            $formatted[] = $obj;
        }

        return $formatted;
    }

    public static function upsert($key, $value) {
        if (array_key_exists($key, self::$VALUES)) {
            self::$VALUES[$key] = $value;
        } else {
            self::$VALUES[$key] = $value;
        }

        update_option("nsi_text_$key", $value);
        wp_cache_flush();
    }

    public static function remove($key) {
        if (array_key_exists($key, self::$VALUES)) {
            unset(self::$VALUES[$key]);
        }

        delete_option("nsi_text_$key");
    }
}
