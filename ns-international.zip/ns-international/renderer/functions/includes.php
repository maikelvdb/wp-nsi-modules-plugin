<?php
require_once __DIR__ . '/ifunction.php';
require_once __DIR__ . '/getNLMonth.php';

use NSInternational\Functions\IFunction;
use function NSInternational\Functions\GetNlMonth;
