<?php
/**
* Plugin Name: NS International modules
* Plugin URI: https://www.maikelvdb.nl/
* Description: Voegt de mogelijkheid toe om NS Internationaal reis modules toe te voegen aan je website.
* Version: 0.0.6
* Author: Maikel van den Bosch
* Author URI: https://www.maikelvdb.nl/
**/

include_once( 'startup.php' );