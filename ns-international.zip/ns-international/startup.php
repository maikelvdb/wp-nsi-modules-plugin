<?php
include_once 'includes/settings.php';
include_once 'includes/search-form.php';
include_once 'includes/calendar.php';
include_once 'includes/day-schedule.php';
include_once 'includes/modules-settings.php';
include_once 'includes/plugin-settings.php';

setModuleSettings();
setPluginSettings();